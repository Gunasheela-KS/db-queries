#list tables in dynamodb

aws dynamodb list-tables 

#add items to dynamodb table music

aws dynamodb put-item --table-name music --item file://song1.json
aws dynamodb put-item --table-name music --item file://song2.json
aws dynamodb put-item --table-name music --item file://song3.json

#Select all items from table where artist name is Sonu nigam

aws dynamodb query --table-name music --key-condition-expression "Artist =:v1" --expression-attribute-values file://values1.json

#Select all items from table music where artist is  v1 and song is v2

aws dynamodb query --table-name music --key-condition-expression "Artist =:v1 AND Song = :v2" --expression-attribute-values file://values2.json

#Delete an item

aws dynamodb delete-item --table-name music --key file://keysToDelete.json

#Scan the table (not efficient)

aws dynamodb scan --table-name music

aws dynamodb put-item --table-name music --item file://song4.json
aws dynamodb put-item --table-name music --item file://song5.json

# add filter expression when querying with attributes other than partition key

aws dynamodb query --table-name music --key-condition-expression "Artist =:v1" --filter-expression "Released= :v2" --expression-attribute-values file://filterValues1.json


aws dynamodb scan --table-name music --filter-expression "AlbumTitle= :v1" --expression-attribute-values file://filterValues2.json

aws dynamodb create-backup --table-name music --backup-name musicBackup


aws dynamodb describe-backup --backup-arn 

aws dynamodb restore-table-from-backup --target-table-name musicRestored --backup-arn arn:aws:dynamodb:us-east-1:130738026255:table/music/backup/01596630381253-81feb24d


aws dynamodb describe-table --table-name musicRestored

aws dynamodb scan --table-name music
aws dynamodb scan --table-name music --max-items 3
aws dynamodb batch-write-item --request-items file://batchWrite.json